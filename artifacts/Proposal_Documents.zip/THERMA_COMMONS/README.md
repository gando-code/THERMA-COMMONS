# THERMA COMMONS sponsorship package

Start with 00_Start_Here.md. The complete PDF combines all 15 documents. Individual Markdown files are editable source documents. JSON files provide editable budget and test-log structures. All project performance and budgets are proposed, not demonstrated.
